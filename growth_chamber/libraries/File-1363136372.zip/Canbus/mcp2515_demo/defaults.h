#ifndef	DEFAULTS_H
#define	DEFAULTS_H

#define	P_MOSI	B,3
#define	P_MISO	B,4
#define	P_SCK	B,5

#define	MCP2515_CS			B,2
#define	MCP2515_INT			D,3

#endif	// DEFAULTS_H
